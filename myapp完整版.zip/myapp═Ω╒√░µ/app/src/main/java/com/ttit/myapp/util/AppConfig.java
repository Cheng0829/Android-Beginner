package com.ttit.myapp.util;

public class AppConfig {
    public static final String BASE_URl = "http://192.168.31.32:8080/renren-fast";
}
