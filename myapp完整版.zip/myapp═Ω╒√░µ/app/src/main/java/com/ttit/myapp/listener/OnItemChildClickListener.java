package com.ttit.myapp.listener;

public interface OnItemChildClickListener {
    void onItemChildClick(int position);
}
