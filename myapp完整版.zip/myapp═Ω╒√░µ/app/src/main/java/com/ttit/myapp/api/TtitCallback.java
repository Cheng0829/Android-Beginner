package com.ttit.myapp.api;

public interface TtitCallback {

    void onSuccess(String res);

    void onFailure(Exception e);
}
