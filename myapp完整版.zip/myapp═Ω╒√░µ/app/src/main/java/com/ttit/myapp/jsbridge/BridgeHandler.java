package com.ttit.myapp.jsbridge;

public interface BridgeHandler {
	
	void handler(String data, CallBackFunction function);

}
