package com.ttit.myapp.listener;

public interface OnItemClickListener {
    void onItemClick(int position);
}